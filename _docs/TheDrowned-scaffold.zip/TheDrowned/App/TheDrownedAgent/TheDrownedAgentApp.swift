import Foundation

// Headless LaunchAgent: wake → poll → post notifications → exit (plan §4.6/§4.7).
// It's an LSUIElement .app (not a CLI tool) so UNUserNotificationCenter has a
// real bundle id to attach to.
@main
enum TheDrownedAgent {
    static func main() async {
        // let store  = try? DrownedStore(...)            // App Group container
        // let sync   = LocalPollingSync(store: store, ...)
        // let notify = NotificationCoordinator(...)
        // if let outcome = try? await sync.sync() { await notify.post(outcome) }
        //
        // NOTE: keep the process alive until UN delivery completes before
        // returning, or the notification may not post before exit.
    }
}
