import SwiftUI

@main
struct TheDrownedApp: App {
    var body: some Scene {
        WindowGroup {
            Text("The Drowned")        // → NavigationSplitView map shell, plan §5.4
                .frame(minWidth: 900, minHeight: 600)
        }
        // onOpenURL for the thedrowned:// deep link (§8)
    }
}
