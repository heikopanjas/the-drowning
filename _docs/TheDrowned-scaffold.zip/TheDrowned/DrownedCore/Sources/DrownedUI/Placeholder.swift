// DrownedUI — placeholder so the target compiles. Replace per the design plan.
